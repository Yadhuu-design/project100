package dao;

import java.sql.*;
import java.util.*;
import java.util.stream.Collectors;
import bean.Concert;

public class ConcertDAO {
    private static final String URL = "jdbc:mysql://192.168.18.245:3306/javadb_168";
    private static final String USER = "javadb_168";
    private static final String PASSWORD = "Sp3cJa5A2k24";
    private static final String DRIVER_CLASS = "com.mysql.jdbc.Driver";

    public ConcertDAO() {
        try {
            Class.forName(DRIVER_CLASS);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    public List<Concert> getAllConcerts() {
        List<Concert> concerts = new ArrayList<>();
        String query = "SELECT concert_id, concert_name, ticket_price, spec, venue, location, concert_date, concert_time, image_url FROM concerts";
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            while (rs.next()) {
                Concert concert = new Concert();
                concert.setConcert_id(rs.getInt("concert_id"));
                concert.setConcert_name(rs.getString("concert_name"));
                concert.setTicket_price(rs.getDouble("ticket_price"));
                concert.setSpec(rs.getString("spec"));
                concert.setVenue(rs.getString("venue"));
                concert.setLocation(rs.getString("location"));
                concert.setConcert_date(rs.getString("concert_date"));
                concert.setConcert_time(rs.getString("concert_time"));
                concert.setImage_url(rs.getString("image_url"));

                concerts.add(concert);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return concerts;
    }

    public Concert getConcertById(int concert_id) {
        Concert concert = null;
        String query = "SELECT concert_id, concert_name, ticket_price, spec, venue, location, concert_date, concert_time, image_url FROM concerts WHERE concert_id = ?";
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement ps = conn.prepareStatement(query)) {

            ps.setInt(1, concert_id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                concert = new Concert();
                concert.setConcert_id(rs.getInt("concert_id"));
                concert.setConcert_name(rs.getString("concert_name"));
                concert.setTicket_price(rs.getDouble("ticket_price"));
                concert.setSpec(rs.getString("spec"));
                concert.setVenue(rs.getString("venue"));
                concert.setLocation(rs.getString("location"));
                concert.setConcert_date(rs.getString("concert_date"));
                concert.setConcert_time(rs.getString("concert_time"));
                concert.setImage_url(rs.getString("image_url"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return concert;
    }

    public boolean updateConcert(Concert concert) {
        String query = "UPDATE concerts SET concert_name = ?, ticket_price = ?, spec = ?, venue = ?, location = ?, concert_date = ?, concert_time = ?, image_url = ? WHERE concert_id = ?";
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, concert.getConcert_name());
            stmt.setDouble(2, concert.getTicket_price());
            stmt.setString(3, concert.getSpec());
            stmt.setString(4, concert.getVenue());
            stmt.setString(5, concert.getLocation());
            stmt.setString(6, concert.getConcert_date());
            stmt.setString(7, concert.getConcert_time());
            stmt.setString(8, concert.getImage_url());
            stmt.setInt(9, concert.getConcert_id());

            int rowsUpdated = stmt.executeUpdate();
            return rowsUpdated > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public static Map<Integer, Concert> getConcertsByIds(Set<Integer> concertIds) throws SQLException {
        Map<Integer, Concert> concerts = new HashMap<>();
        if (concertIds.isEmpty()) {
            return concerts;
        }

        String ids = concertIds.stream().map(String::valueOf).collect(Collectors.joining(","));
        String query = "SELECT * FROM concerts WHERE concert_id IN (" + ids + ")";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement ps = conn.prepareStatement(query);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Concert concert = new Concert();
                concert.setConcert_id(rs.getInt("concert_id"));
                concert.setConcert_name(rs.getString("concert_name"));
                concert.setTicket_price(rs.getDouble("ticket_price"));
                concert.setSpec(rs.getString("spec"));
                concert.setVenue(rs.getString("venue"));
                concert.setLocation(rs.getString("location"));
                concert.setConcert_date(rs.getString("concert_date"));
                concert.setConcert_time(rs.getString("concert_time"));
                concert.setImage_url(rs.getString("image_url"));

                concerts.put(concert.getConcert_id(), concert);
            }
        }

        return concerts;
    }
}
